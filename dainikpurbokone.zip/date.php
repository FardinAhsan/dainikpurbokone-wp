<?php get_header();

if(is_year()){
    $year = get_query_var('year');
} elseif(is_month()){
    $month = get_query_var('monthnum');
    $dateObj = DateTime::createFromFormat("!m", $month);
    $monthName = $dateObj->format("F");
}else if(is_day()){
    $year = get_query_var('year');
    $month = get_query_var('monthnum');
    $day = get_query_var('day');
    $dateObj = DateTime::createFromFormat("!m", $month);
    $monthName = $dateObj->format("F");

}
    $args = array(
        'get' => 'all',
        'hide_empty' => 0
    );
    $categories = get_categories( $args );
    $cats = [];
    foreach($categories as $category):
        array_push($cats, $category->name);
    endforeach;
?>



<div class="home-page">
    <div class="container">
        <div class="row">
        <div class="col-lg-9">
            <div class="category-news">
                <div class="row">
                    <?php 
                        // echo do_shortcode("[date_news year='{$year}' month='{$month}' day='{$day}']");
                        foreach($cats as $cat):
                                echo do_shortcode('[date_news cat="'.$cat.'" year="'.$year.'" month="'.$month.'" day="'.$day.'"]');
                        endforeach;
                    ?>
                </div>    
            </div>
        </div>
            <?php get_sidebar(); ?>
        </div>
    </div>
</div>












<?php get_footer(); 