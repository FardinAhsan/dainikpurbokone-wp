<button id="scrollToTopButton" onclick="scrollToTop(100,3);"><i class="fa fa-arrow-up"></i></button>
<?php wp_footer(); ?>

</body>

</html>