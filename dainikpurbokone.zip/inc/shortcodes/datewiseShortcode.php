<?php

function dpkone_dateWiseQuery($attr){

    $default = array(
        'cat' => '',
        'year' => '',
        'month' => '',
        'day' => '',
    );

    extract( shortcode_atts( $default, $attr, 'date_news' ) );
    $args = array(
        'status' => 'publish',
        'posts_per_page' => -1,
        'category_name' => (isset($cat)) ? $cat : '',
        'date_query' => array(
            array(
                'year'  => (isset($year)) ? $year : '',
                'month' => (isset($month)) ? $month : '',
                'day'   => (isset($day)) ? $day : '',
            ),
        ),
    );
    
    $q = new WP_Query($args);
    

    $html = '
            <div class="col-lg-6">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="category-news-bar">
                            <a href="category/'.$cat.'"><h3>'.$cat.'</h3>
                            <i class="fas fa-long-arrow-alt-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="row">';

    while($q->have_posts()): $q->the_post();

        $id = get_the_ID();
        $title = get_the_title();
        $date = get_the_date('F j, Y');
        $location=get_post_meta( "dp_w_location", true );
        $the_post_cover = get_the_post_thumbnail($id, '', array('class'=> 'img-fluid', 'alt'=> 'DainikPurbokone'));

        $html .= '<div class="col-lg-6 col-sm-6 mb-2">
                <div class="single-news">
                    <div class="single-news-img">
                        <a href="'.get_permalink().'">'.$the_post_cover.'</a>
                        <div class="single-news-img-date-time">
                            <p class="single-date-time">'.$date.'</p>
                            <p class="single-division">'.$location.'</p>
                        </div>
                    </div>
                    <div class="single-news-heding">
                        <a href="'.get_permalink().'">
                            <h6>'.$title.'</h6>
                        </a>
                    </div>
                </div>
            </div>';

    endwhile;
    wp_reset_query();

    $html .='
            </div>
            </div>';

    return $html;

}
add_shortcode('date_news', 'dpkone_dateWiseQuery');