<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset') ?>">
    <?php wp_head(); ?>
</head>
<body>
    <!-- Preloader -->
   <div id="preloader">
        <div id="preloader-center">
            <div id="preloader-center-block">
                <div class="anim"></div>
                <div class="anim"></div>
                <div class="anim"></div>
                <div class="anim"></div>
                <div class="anim"></div>
                <div class="anim"></div>
                <div class="anim"></div>
                <div class="anim"></div>
                <div class="anim"></div>
                <div class="anim"></div>
            </div>
        </div>
    </div> 
    <!-- End Preloader -->
    <div class="headerTopBar fix">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-8">
                    <p class="top_date"><?php echo do_shortcode('[english_date]'); ?>, <?php echo do_shortcode('[bangla_day]'); ?>, <?php echo do_shortcode('[bangla_time]'); ?> | <?php echo do_shortcode('[bangla_date]'); ?></p>
                </div>
                <div class="col-lg-6 col-md-4">
                    <ul class="top_social_bar">
                        <li><a href="" targer="_blank"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="" targer="_blank"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="" targer="_blank"><i class="fab fa-youtube"></i></a></li>
                        <li><a href="" targer="_blank"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="headerMiddleBar fix">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 logo-sm">
                    <div class="navbar-brand logoBar">
                    <?php
                    if (has_custom_logo()) :
                        if (function_exists(the_custom_logo())) :
                        the_custom_logo();
                    endif;
                    ?>
					<?php else : ?>

                        <a href="<?php echo esc_url(site_url('/')); ?>" class="logo">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/logo.png" class="img-fluid" alt="<?php echo esc_attr(get_bloginfo('name', 'display')); ?>">
                        </a>

                    <?php endif; ?>

                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="addVertise">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/addvertise.png" alt="Dainik Purbokone" class="img-fluid">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="news_stickr_area">
            <div class="row">
                <div class="col-lg-2 trending">
                    <div class="top-news-heading">
                        <h3>শিরোনামঃ </h3>
                    </div>
                </div>
                <div class="col-lg-10 no-padding">
                    <div class="owl-carousel owl-theme all-news" id="newStickr">
                    
                    <?php 
                    $args = array(
                        'status' => 'publish',
                        'post_type' => 'post',
                        'posts_per_page' => 10,
                        'order' => 'DESC',
                    );
                    $stickr_news = new WP_Query($args);
                    ?>
                    <?php if ($stickr_news->have_posts()) : ?>

                    <?php while ($stickr_news->have_posts()) : $stickr_news->the_post() ?>

                        <div class="stickr-news-item">
                            <a href="<?php esc_url(the_permalink()); ?>"><i class="fa fa-angle-double-right"></i>
                                <span> <?php esc_html__(the_title()); ?></span>
                            </a>
                        </div>

                    <?php endwhile; ?>

						<?php wp_reset_postdata(); ?>

					<?php else : ?>

                        <p><?php _e('Sorry, no posts matched your criteria.'); ?></p>

					<?php endif; ?>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    <nav class="headerNavMenu fix">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                <?php
                wp_nav_menu([
                    'theme_location' => 'header_nav',
                    'container' => 'div',
                    'container_id' => 'headerNav',
                    'container_class' => 'nav_container',
                    'menu_id' => false,
                    'menu_class' => 'menu_container',
                ]);
                ?>
                    <!-- <div class="nav_container">
                        <ul class="menu_container">
                            <li class="main_page">
                                <a href="index.html">
                                    <i class="fas fa-home home_icon"></i>
                                    মূলপাতা
                                </a>
                            </li>
                            <li>
                                <a href="">জাতীয় জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয় জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li>
                                <a href="">জাতীয়</a>
                            </li>
                            <li class="others_page">
                                <a href="">
                                    অন্যান্য বিভাগ
                                    <i class="fas fa-caret-down caret_icon"></i>
                                </a>
                            </li>
                        </ul>
                    </div> -->
                </div>
            </div>
        </div>
    </nav>